export const samples = [
  { id: 'property-101', name: 'Riverside House', address: '12 Riverside Lane', connectedMeters: ['meter-01', 'meter-02', 'meter-03'] },
  { id: 'property-202', name: 'Orchard Studio', address: '8 Orchard Road', connectedMeters: ['meter-04'] },
  { id: 'property-303', name: 'Unassigned property', address: 'No connected meters yet', connectedMeters: [] },
];
export const meterSamples = [
  { id: 'meter-01', name: 'Main electricity', serial: 'EL-004817', kind: 'Electricity', reading: '12,842', unit: 'kWh' },
  { id: 'meter-02', name: 'Water supply', serial: 'WA-008235', kind: 'Water', reading: '386', unit: 'm³' },
  { id: 'meter-03', name: 'Heating gas', serial: 'GA-002619', kind: 'Gas', reading: '2,174', unit: 'm³' },
  { id: 'meter-04', name: 'Studio electricity', serial: 'EL-009531', kind: 'Electricity', reading: '5,120', unit: 'kWh' },
];
export function graphFor(property, meters) {
  const rootId = `property:${property.id}`;
  const meterMap = new Map(meters.map(m => [m.id, m]));
  const ids = [...new Set(property.connectedMeters)];
  const missing = ids.filter(id => !meterMap.has(id));
  const connected = ids.filter(id => meterMap.has(id)).map(id => meterMap.get(id));
  const step = 274;
  return {
    nodes: [
      { id: rootId, type: 'property', position: { x: 0, y: 0 }, data: property },
      ...connected.map((meter, i) => ({ id: `meter:${meter.id}`, type: 'meter', position: { x: (i - (connected.length - 1) / 2) * step, y: 228 }, data: meter })),
    ],
    edges: connected.map(m => ({ id: `${rootId}->meter:${m.id}`, source: rootId, target: `meter:${m.id}`, type: 'smoothstep' })),
    missing,
  };
}
