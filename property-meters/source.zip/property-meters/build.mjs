import {build} from 'esbuild';
import fs from 'node:fs';
const result = await build({entryPoints:['app.jsx'],bundle:true,write:false,minify:true,format:'iife',outfile:'app.js',define:{'process.env.NODE_ENV':'"production"'},legalComments:'inline',loader:{'.woff2':'dataurl'}});
const js=result.outputFiles.find(f=>f.path.endsWith('.js')).text;
const css=result.outputFiles.find(f=>f.path.endsWith('.css')).text;
const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Property and connected meters — interactive sample</title><style>${css}</style></head><body><div id="root"></div><script>${js.replaceAll('</script','<\\/script')}</script></body></html>`;
fs.mkdirSync('dist',{recursive:true});fs.writeFileSync('dist/index.html',html);console.log(JSON.stringify({file:'dist/index.html',bytes:Buffer.byteLength(html)}));
