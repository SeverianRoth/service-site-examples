import test from 'node:test';
import assert from 'node:assert/strict';
import { graphFor } from './model.mjs';

test('uses only linked meters and keeps colliding record-type IDs distinct', () => {
  const result = graphFor({ id: 'same', connectedMeters: ['same'] }, [{ id: 'same' }, { id: 'unrelated' }]);
  assert.deepEqual(result.nodes.map(n => n.id), ['property:same', 'meter:same']);
  assert.equal(result.edges[0].source, 'property:same');
  assert.equal(result.edges[0].target, 'meter:same');
  assert.ok(result.nodes[0].position.y < result.nodes[1].position.y);
});
test('duplicates and missing references do not fabricate extra graph records', () => {
  const result = graphFor({ id: 'p', connectedMeters: ['m', 'm', 'missing'] }, [{ id: 'm' }]);
  assert.equal(result.nodes.length, 2);
  assert.equal(result.edges.length, 1);
  assert.deepEqual(result.missing, ['missing']);
});
test('removing and adding relationships preserves surviving node IDs', () => {
  const before = graphFor({ id: 'p', connectedMeters: ['a', 'b'] }, [{ id: 'a' }, { id: 'b' }]);
  const after = graphFor({ id: 'p', connectedMeters: ['b'] }, [{ id: 'a' }, { id: 'b' }]);
  assert.equal(after.nodes[1].id, before.nodes[2].id);
  assert.equal(after.edges.length, 1);
  const empty = graphFor({ id: 'p', connectedMeters: [] }, []);
  assert.equal(empty.nodes.length, 1);
  assert.deepEqual(empty.edges, []);
});
