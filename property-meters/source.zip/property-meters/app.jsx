import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ReactFlow, Background, Controls, Handle, Position } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import './style.css';
import { samples, meterSamples, graphFor } from './model.mjs';

const icons = { Electricity: '↯', Water: '◉', Gas: '♨' };
function PropertyNode({ data }) {
  return <div className="property-node"><div className="node-label">PROPERTY</div><h2>{data.name}</h2><p>{data.address}</p><Handle type="source" position={Position.Bottom}/></div>;
}
function MeterNode({ data, selected }) {
  return <div className={`meter-node ${selected ? 'selected' : ''}`}><Handle type="target" position={Position.Top}/><div className="meter-heading"><span className={`utility ${data.kind.toLowerCase()}`}>{icons[data.kind]}</span><span>{data.kind}</span><span className="linked">Connected</span></div><h3>{data.name}</h3><p className="serial">{data.serial}</p><div className="reading">{data.reading}<small>{data.unit}</small></div><div className="node-hint">Click to view meter →</div></div>;
}
const nodeTypes = { property: PropertyNode, meter: MeterNode };
function App() {
  const [properties, setProperties] = useState(samples);
  const [meters, setMeters] = useState(meterSamples);
  const [propertyId, setPropertyId] = useState(samples[0].id);
  const [selectedId, setSelectedId] = useState(null);
  const property = properties.find(p => p.id === propertyId);
  const graph = useMemo(() => graphFor(property, meters), [property, meters]);
  const selected = graph.nodes.find(n => n.id === selectedId && n.type === 'meter')?.data;
  const nodes = graph.nodes.map(n => ({ ...n, selected: n.id === selectedId }));
  function connect() {
    const id = `sample-${meters.length + 1}`;
    const added = { id, name: 'Additional electricity', serial: `EL-DEMO-${meters.length + 1}`, kind: 'Electricity', reading: '0', unit: 'kWh' };
    setMeters(ms => [...ms, added]);
    setProperties(ps => ps.map(p => p.id === propertyId ? { ...p, connectedMeters: [...p.connectedMeters, id] } : p));
  }
  function disconnect() {
    setProperties(ps => ps.map(p => p.id === propertyId ? { ...p, connectedMeters: p.connectedMeters.slice(0, -1) } : p));
    setSelectedId(null);
  }
  return <main><header><div className="brand"><span className="brand-icon">⌘</span>Property connections</div><span className="sample-badge">INTERACTIVE SAMPLE</span></header><section className="intro"><div><div className="eyebrow">PROPERTY → CONNECTED METERS</div><h1>One property. Every connection.</h1><p>Select a property to see its meters. Click a meter to view its details.</p></div><div className="selector"><label htmlFor="property">Property</label><select id="property" value={propertyId} onChange={e => {setPropertyId(e.target.value);setSelectedId(null);}}>{properties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div></section><section className="workspace"><div className="canvas-top"><span><b>{graph.edges.length}</b> connected meters</span><div className="actions"><button onClick={connect} disabled={graph.edges.length >= 6}>+ Connect sample meter</button><button onClick={disconnect} disabled={!graph.edges.length}>Disconnect last</button></div></div><div className="canvas"><ReactFlow key={`${propertyId}:${graph.edges.length}`} nodes={nodes} edges={graph.edges} nodeTypes={nodeTypes} fitView fitViewOptions={{padding: 0.24, maxZoom: 1.05}} minZoom={0.2} maxZoom={1.5} nodesDraggable={false} nodesConnectable={false} onNodeClick={(_,n) => setSelectedId(n.id)} defaultEdgeOptions={{style:{stroke:'#7d93b4',strokeWidth:1.5}, pathOptions:{borderRadius:18}}}><Background color="#cfd7e4" gap={22} size={1}/><Controls showInteractive={false}/></ReactFlow>{!graph.edges.length && <div className="empty">No meters connected to this property.<br/><small>Use “Connect sample meter” to add one.</small></div>}</div><aside className="details">{selected ? <><span className={`utility ${selected.kind.toLowerCase()}`}>{icons[selected.kind]}</span><div><span className="detail-label">SELECTED METER</span><strong>{selected.name}</strong></div><div><span className="detail-label">SERIAL NUMBER</span><strong>{selected.serial}</strong></div><div><span className="detail-label">LAST READING</span><strong>{selected.reading} {selected.unit}</strong></div></> : <span>Select a meter above to see its details.</span>}</aside></section><footer><span>Interactive demo · React Flow · Example data</span><span>Severian Roth</span></footer></main>;
}
createRoot(document.getElementById('root')).render(<App/>);
