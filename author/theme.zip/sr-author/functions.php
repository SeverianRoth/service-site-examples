<?php
add_action('wp_enqueue_scripts', function () { wp_enqueue_style('sr-demo',get_stylesheet_uri(),array(),'1.0.0'); wp_enqueue_script('sr-demo',get_stylesheet_directory_uri().'/app.js',array(),'1.0.0',true); });
add_filter('show_admin_bar','__return_false');
